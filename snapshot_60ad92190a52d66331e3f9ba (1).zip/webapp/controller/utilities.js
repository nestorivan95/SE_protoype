sap.ui.define([
	"./utilities"
], function() {
	"use strict";

	// class providing static utility methods to retrieve entity default values.

	return {
		getDefaultValuesForAgregarTareas: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Nombre": "",
				"Descripcion": "",
				"FechaInicio": null,
				"FechaFin": "",
				"Estado": "",
				"FechaEsperada": null,
				"___FK_e792372c4ec8d96015706cfe_00002": "",
				"___FK_98312a27c779afd815798006_00003": ""
			};
		},
		getDefaultValuesForAgregarCapacitacion: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"Nombre": "",
				"Empresa": "",
				"Mes": "Enero",
				"___FK_d2081ce807d6b07f15706cc7_00037": ""
			};
		}
	};
});
